#!/bin/sh
case $USER in
tangqi|tangqi_)
	echo "Welcome $USER"
	echo "please enjoy you visit";;
testing)
	echo "special tesing accout";;
jessica)
	echo "Do not forget to log off when you're done";;
*)
	echo "Sorry,you are not allowed here";;
esac

