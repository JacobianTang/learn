#!/bin/sh
if [[ $USER == t* ]]
then
	echo "hello $USER"
else
	echo "Sorry.I do not konw you"
fi
